package com.example.w3d3restclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class W3D3RestClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
