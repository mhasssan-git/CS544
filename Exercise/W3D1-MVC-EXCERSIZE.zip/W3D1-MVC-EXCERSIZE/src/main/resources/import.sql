INSERT INTO Book VALUES(NULL, '9780553293357', 'Isaac Asimov', 20.00, 'Foundation'   );
INSERT INTO Book VALUES(NULL, '9780553293371'   , 'Isaac Asimov', 25.00, 'Foundation & Empire');